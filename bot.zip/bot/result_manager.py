from __future__ import annotations

import json
from pathlib import Path


BASE_DIR = Path(__file__).resolve().parent
RESULTS_DIR = BASE_DIR / "results"
ANSWER_SHEETS_DIR = RESULTS_DIR / "answer_sheets"
RESULTS_FILE = RESULTS_DIR / "results.json"


def ensure_storage() -> None:
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    ANSWER_SHEETS_DIR.mkdir(parents=True, exist_ok=True)

    if not RESULTS_FILE.exists():
        RESULTS_FILE.write_text("[]", encoding="utf-8")


def save_result_summary(result: dict) -> None:
    ensure_storage()

    try:
        existing_results = json.loads(RESULTS_FILE.read_text(encoding="utf-8"))
        if not isinstance(existing_results, list):
            existing_results = []
    except (json.JSONDecodeError, OSError):
        existing_results = []

    existing_results.append(result)
    RESULTS_FILE.write_text(
        json.dumps(existing_results, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )


def save_answer_sheet_json(answer_sheet: dict) -> str:
    ensure_storage()
    file_path = (
        ANSWER_SHEETS_DIR
        / f"answer_sheet_{answer_sheet['user_id']}_{answer_sheet['file_timestamp']}.json"
    )

    file_path.write_text(
        json.dumps(answer_sheet, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    return str(file_path)


def save_answer_sheet_txt(answer_sheet: dict) -> str:
    ensure_storage()
    file_path = (
        ANSWER_SHEETS_DIR
        / f"answer_sheet_{answer_sheet['user_id']}_{answer_sheet['file_timestamp']}.txt"
    )

    lines = [
        "English Quiz Answer Sheet",
        "",
        f"Name: {answer_sheet['name']}",
        f"Username: {answer_sheet['username'] or 'N/A'}",
        f"Test: {answer_sheet['test_name']}",
        f"Level: {answer_sheet['level']}",
        f"Version: {answer_sheet['version']}",
        f"Started: {answer_sheet['started_at']}",
        f"Finished: {answer_sheet['finished_at']}",
        f"Time: {answer_sheet['elapsed_text']}",
        "",
        f"Score: {answer_sheet['correct']}/{answer_sheet['total_questions']}",
        f"Wrong: {answer_sheet['wrong']}",
        f"Skipped: {answer_sheet['skipped_questions']}",
        f"Percentage: {answer_sheet['percentage']}%",
        "",
        "Question Review:",
        "",
    ]

    for index, answer in enumerate(answer_sheet["full_answer_review"], start=1):
        lines.extend(_build_txt_review_block(index, answer))

    file_path.write_text("\n".join(lines).strip() + "\n", encoding="utf-8")
    return str(file_path)


def _build_txt_review_block(index: int, answer: dict) -> list[str]:
    result_text = "Correct" if answer["is_correct"] else "Wrong"
    if answer["was_skipped"]:
        result_text = "Skipped"

    lines = [
        f"{index}. {answer['question_text']}",
        f"Your answer: {_format_user_answer(answer)}",
    ]

    if answer["type"] == "text_input":
        lines.append(f"Accepted answers: {', '.join(answer['correct_answer_texts'])}")
    else:
        lines.append(f"Correct answer: {_format_correct_answer(answer)}")

    lines.extend(
        [
            f"Result: {result_text}",
            f"Explanation: {answer['explanation']}",
            "",
        ]
    )
    return lines


def _format_user_answer(answer: dict) -> str:
    if answer["was_skipped"]:
        return "Skipped"

    if answer["type"] == "single_choice":
        return answer["user_answer_text"]
    if answer["type"] == "multiple_choice":
        if not answer["user_answer_texts"]:
            return "Skipped"
        return ", ".join(answer["user_answer_texts"])
    return answer["user_answer_text"] or "(empty)"


def _format_correct_answer(answer: dict) -> str:
    if answer["type"] == "single_choice":
        return answer["correct_answer_text"]
    if answer["type"] == "multiple_choice":
        return ", ".join(answer["correct_answer_texts"])
    return ", ".join(answer["correct_answer_texts"])


ensure_storage()
