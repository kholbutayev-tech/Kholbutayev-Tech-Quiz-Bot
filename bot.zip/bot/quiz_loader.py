from __future__ import annotations

import json
from pathlib import Path


SUPPORTED_QUESTION_TYPES = {"single_choice", "multiple_choice", "text_input"}


def load_quiz(file_path: str) -> dict:
    path = Path(file_path)

    with path.open("r", encoding="utf-8") as file:
        data = json.load(file)

    if not isinstance(data, dict):
        raise ValueError("Quiz file must contain a JSON object.")

    test_name = data.get("test_name")
    level = data.get("level")
    version = data.get("version") or "unknown"
    questions = data.get("questions")

    if not isinstance(test_name, str) or not test_name.strip():
        raise ValueError("Quiz must include a non-empty 'test_name'.")

    if not isinstance(level, str) or not level.strip():
        raise ValueError("Quiz must include a non-empty 'level'.")

    if not isinstance(questions, list) or not questions:
        raise ValueError("Quiz must include a non-empty 'questions' list.")

    normalized_questions = []
    for index, question in enumerate(questions, start=1):
        normalized_questions.append(_validate_question(question, index))

    return {
        "test_name": test_name.strip(),
        "level": level.strip(),
        "version": str(version).strip() or "unknown",
        "questions": normalized_questions,
    }


def _validate_question(question: object, question_number: int) -> dict:
    if not isinstance(question, dict):
        raise ValueError(f"Question {question_number} must be a JSON object.")

    required_fields = ("id", "type", "question", "explanation")
    for field_name in required_fields:
        if field_name not in question:
            raise ValueError(f"Question {question_number} is missing '{field_name}'.")

    question_type = question["type"]
    if question_type not in SUPPORTED_QUESTION_TYPES:
        raise ValueError(
            f"Question {question_number} has unsupported type '{question_type}'."
        )

    question_text = question["question"]
    explanation = question["explanation"]
    if not isinstance(question_text, str) or not question_text.strip():
        raise ValueError(f"Question {question_number} must have non-empty 'question' text.")
    if not isinstance(explanation, str) or not explanation.strip():
        raise ValueError(f"Question {question_number} must have non-empty 'explanation'.")

    normalized_question = {
        "id": question["id"],
        "type": question_type,
        "question": question_text.strip(),
        "explanation": explanation.strip(),
    }

    if question_type == "single_choice":
        options = _validate_options(question, question_number)
        correct_answer = question.get("correct_answer")
        if not isinstance(correct_answer, int):
            raise ValueError(f"Question {question_number} must have integer 'correct_answer'.")
        if correct_answer < 0 or correct_answer >= len(options):
            raise ValueError(
                f"Question {question_number} has invalid 'correct_answer' index."
            )

        normalized_question["options"] = options
        normalized_question["correct_answer"] = correct_answer

    elif question_type == "multiple_choice":
        options = _validate_options(question, question_number)
        correct_answers = question.get("correct_answers")
        if not isinstance(correct_answers, list) or not correct_answers:
            raise ValueError(
                f"Question {question_number} must have non-empty 'correct_answers'."
            )
        if any(not isinstance(answer_index, int) for answer_index in correct_answers):
            raise ValueError(
                f"Question {question_number} has non-integer values in 'correct_answers'."
            )
        if any(
            answer_index < 0 or answer_index >= len(options)
            for answer_index in correct_answers
        ):
            raise ValueError(
                f"Question {question_number} has out-of-range indexes in 'correct_answers'."
            )
        if len(set(correct_answers)) != len(correct_answers):
            raise ValueError(
                f"Question {question_number} contains duplicate indexes in 'correct_answers'."
            )

        normalized_question["options"] = options
        normalized_question["correct_answers"] = correct_answers

    elif question_type == "text_input":
        correct_answers = question.get("correct_answers")
        if not isinstance(correct_answers, list) or not correct_answers:
            raise ValueError(
                f"Question {question_number} must have non-empty 'correct_answers'."
            )
        if any(
            not isinstance(answer_text, str) or not answer_text.strip()
            for answer_text in correct_answers
        ):
            raise ValueError(
                f"Question {question_number} must have non-empty string values in 'correct_answers'."
            )

        normalized_question["correct_answers"] = [answer_text.strip() for answer_text in correct_answers]
        normalized_question["case_sensitive"] = bool(question.get("case_sensitive", False))

    return normalized_question


def _validate_options(question: dict, question_number: int) -> list[str]:
    options = question.get("options")
    if not isinstance(options, list):
        raise ValueError(f"Question {question_number} must include an 'options' list.")
    if not 2 <= len(options) <= 10:
        raise ValueError(f"Question {question_number} must have 2 to 10 options.")
    if any(not isinstance(option, str) or not option.strip() for option in options):
        raise ValueError(f"Question {question_number} has invalid option text.")
    return [option.strip() for option in options]
