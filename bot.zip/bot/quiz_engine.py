from __future__ import annotations

from copy import deepcopy
from datetime import datetime


active_sessions: dict[int, dict] = {}


def start_session(user, chat_id: int, quiz: dict) -> dict:
    quiz_copy = deepcopy(quiz)
    started_at_dt = datetime.now().astimezone()
    total_questions = len(quiz_copy["questions"])

    session = {
        "user_id": user.id,
        "chat_id": chat_id,
        "name": user.full_name or user.first_name or str(user.id),
        "username": f"@{user.username}" if user.username else "",
        "test_name": quiz_copy["test_name"],
        "level": quiz_copy["level"],
        "version": quiz_copy["version"],
        "started_at": started_at_dt.isoformat(timespec="seconds"),
        "started_at_dt": started_at_dt,
        "current_question_index": 0,
        "answers": [],
        "quiz": quiz_copy,
        "allowed_skips": max(1, total_questions // 10),
        "used_skips": 0,
        "skipped_question_indexes": [],
        "current_question_message_ids": [],
        "multi_selected": {},
    }

    active_sessions[user.id] = session
    return session


def get_session(user_id: int) -> dict | None:
    return active_sessions.get(user_id)


def get_current_question(user_id: int) -> dict | None:
    session = get_session(user_id)
    if not session:
        return None

    question_index = session["current_question_index"]
    questions = session["quiz"]["questions"]
    if question_index < 0 or question_index >= len(questions):
        return None

    return questions[question_index]


def get_total_questions(user_id: int) -> int:
    session = get_session(user_id)
    if not session:
        return 0
    return len(session["quiz"]["questions"])


def already_answered(user_id: int, question_index: int) -> bool:
    session = get_session(user_id)
    if not session:
        return False

    return any(
        answer["question_index"] == question_index for answer in session["answers"]
    )


def record_single_choice_answer(
    user_id: int, question_index: int, option_index: int
) -> dict | None:
    session = get_session(user_id)
    question = get_current_question(user_id)

    if not session or not question:
        return None
    if question["type"] != "single_choice":
        return None
    if question_index != session["current_question_index"]:
        return None
    if already_answered(user_id, question_index):
        return None
    if option_index < 0 or option_index >= len(question["options"]):
        return None

    correct_answer_index = question["correct_answer"]
    answer = {
        "question_index": question_index,
        "question_id": question["id"],
        "type": question["type"],
        "question_text": question["question"],
        "options": question["options"],
        "user_answer_index": option_index,
        "user_answer_text": question["options"][option_index],
        "correct_answer_index": correct_answer_index,
        "correct_answer_text": question["options"][correct_answer_index],
        "is_correct": option_index == correct_answer_index,
        "was_skipped": False,
        "explanation": question["explanation"],
    }

    session["answers"].append(answer)
    session["multi_selected"].pop(question_index, None)
    return answer


def toggle_multi_option(
    user_id: int, question_index: int, option_index: int
) -> list[int] | None:
    session = get_session(user_id)
    question = get_current_question(user_id)

    if not session or not question:
        return None
    if question["type"] != "multiple_choice":
        return None
    if question_index != session["current_question_index"]:
        return None
    if already_answered(user_id, question_index):
        return None
    if option_index < 0 or option_index >= len(question["options"]):
        return None

    selected_options = session["multi_selected"].setdefault(question_index, set())
    if option_index in selected_options:
        selected_options.remove(option_index)
    else:
        selected_options.add(option_index)

    return sorted(selected_options)


def get_multi_selected(user_id: int, question_index: int) -> list[int]:
    session = get_session(user_id)
    if not session:
        return []
    return sorted(session["multi_selected"].get(question_index, set()))


def record_multiple_choice_answer(user_id: int, question_index: int) -> dict | None:
    session = get_session(user_id)
    question = get_current_question(user_id)

    if not session or not question:
        return None
    if question["type"] != "multiple_choice":
        return None
    if question_index != session["current_question_index"]:
        return None
    if already_answered(user_id, question_index):
        return None

    selected_indexes = get_multi_selected(user_id, question_index)
    if not selected_indexes:
        return None

    correct_indexes = question["correct_answers"]
    answer = {
        "question_index": question_index,
        "question_id": question["id"],
        "type": question["type"],
        "question_text": question["question"],
        "options": question["options"],
        "user_answer_indexes": selected_indexes,
        "user_answer_texts": [question["options"][index] for index in selected_indexes],
        "correct_answer_indexes": correct_indexes,
        "correct_answer_texts": [question["options"][index] for index in correct_indexes],
        "is_correct": set(selected_indexes) == set(correct_indexes),
        "was_skipped": False,
        "explanation": question["explanation"],
    }

    session["answers"].append(answer)
    session["multi_selected"].pop(question_index, None)
    return answer


def record_text_answer(user_id: int, question_index: int, text: str) -> dict | None:
    session = get_session(user_id)
    question = get_current_question(user_id)

    if not session or not question:
        return None
    if question["type"] != "text_input":
        return None
    if question_index != session["current_question_index"]:
        return None
    if already_answered(user_id, question_index):
        return None

    cleaned_text = text.strip()
    if question.get("case_sensitive", False):
        is_correct = cleaned_text in question["correct_answers"]
    else:
        lowered_text = cleaned_text.lower()
        is_correct = any(
            lowered_text == answer_text.lower()
            for answer_text in question["correct_answers"]
        )

    answer = {
        "question_index": question_index,
        "question_id": question["id"],
        "type": question["type"],
        "question_text": question["question"],
        "user_answer_text": cleaned_text,
        "correct_answer_texts": question["correct_answers"],
        "is_correct": is_correct,
        "was_skipped": False,
        "explanation": question["explanation"],
    }

    session["answers"].append(answer)
    return answer


def record_skip(user_id: int, question_index: int) -> dict | None:
    session = get_session(user_id)
    question = get_current_question(user_id)

    if not session or not question:
        return None
    if question["type"] == "text_input":
        return None
    if question_index != session["current_question_index"]:
        return None
    if already_answered(user_id, question_index):
        return None
    if not can_skip(user_id):
        return None

    if question["type"] == "single_choice":
        answer = {
            "question_index": question_index,
            "question_id": question["id"],
            "type": question["type"],
            "question_text": question["question"],
            "options": question["options"],
            "user_answer_index": None,
            "user_answer_text": "Skipped",
            "correct_answer_index": question["correct_answer"],
            "correct_answer_text": question["options"][question["correct_answer"]],
            "is_correct": False,
            "was_skipped": True,
            "explanation": question["explanation"],
        }
    else:
        answer = {
            "question_index": question_index,
            "question_id": question["id"],
            "type": question["type"],
            "question_text": question["question"],
            "options": question["options"],
            "user_answer_indexes": [],
            "user_answer_texts": [],
            "correct_answer_indexes": question["correct_answers"],
            "correct_answer_texts": [
                question["options"][index] for index in question["correct_answers"]
            ],
            "is_correct": False,
            "was_skipped": True,
            "explanation": question["explanation"],
        }

    session["answers"].append(answer)
    session["used_skips"] += 1
    session["skipped_question_indexes"].append(question_index)
    session["multi_selected"].pop(question_index, None)
    return answer


def can_skip(user_id: int) -> bool:
    session = get_session(user_id)
    if not session:
        return False
    return session["used_skips"] < session["allowed_skips"]


def is_finished(user_id: int) -> bool:
    session = get_session(user_id)
    if not session:
        return False
    return len(session["answers"]) >= len(session["quiz"]["questions"])


def move_to_next_question(user_id: int) -> None:
    session = get_session(user_id)
    if not session:
        return
    session["current_question_index"] += 1


def build_result(user_id: int) -> dict | None:
    session = get_session(user_id)
    if not session:
        return None

    finished_at_dt = datetime.now().astimezone()
    finished_at = finished_at_dt.isoformat(timespec="seconds")
    elapsed_seconds = int((finished_at_dt - session["started_at_dt"]).total_seconds())
    total_questions = len(session["quiz"]["questions"])
    correct = sum(1 for answer in session["answers"] if answer["is_correct"])
    skipped_questions = sum(1 for answer in session["answers"] if answer["was_skipped"])
    answered_questions = total_questions - skipped_questions
    wrong = total_questions - correct
    percentage = round((correct / total_questions) * 100, 2)

    full_answer_review = sorted(
        deepcopy(session["answers"]),
        key=lambda answer: answer["question_index"],
    )

    return {
        "user_id": session["user_id"],
        "name": session["name"],
        "username": session["username"],
        "test_name": session["test_name"],
        "level": session["level"],
        "version": session["version"],
        "started_at": session["started_at"],
        "finished_at": finished_at,
        "elapsed_seconds": elapsed_seconds,
        "elapsed_text": format_elapsed_time(elapsed_seconds),
        "file_timestamp": finished_at_dt.strftime("%Y-%m-%d_%H-%M-%S"),
        "total_questions": total_questions,
        "answered_questions": answered_questions,
        "skipped_questions": skipped_questions,
        "correct": correct,
        "wrong": wrong,
        "percentage": percentage,
        "full_answer_review": full_answer_review,
    }


def end_session(user_id: int) -> None:
    active_sessions.pop(user_id, None)


def format_elapsed_time(elapsed_seconds: int) -> str:
    minutes, seconds = divmod(elapsed_seconds, 60)
    hours, minutes = divmod(minutes, 60)

    parts = []
    if hours:
        parts.append(f"{hours} hour{'s' if hours != 1 else ''}")
    if minutes:
        parts.append(f"{minutes} minute{'s' if minutes != 1 else ''}")
    parts.append(f"{seconds} second{'s' if seconds != 1 else ''}")
    return " ".join(parts)
