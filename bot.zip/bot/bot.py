from __future__ import annotations

from pathlib import Path

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.error import TelegramError
from telegram.ext import (
    ApplicationBuilder,
    CallbackQueryHandler,
    CommandHandler,
    ContextTypes,
    MessageHandler,
    filters,
)

from config import BOT_TOKEN
from quiz_engine import (
    already_answered,
    build_result,
    can_skip,
    end_session,
    get_current_question,
    get_multi_selected,
    get_session,
    get_total_questions,
    is_finished,
    move_to_next_question,
    record_multiple_choice_answer,
    record_single_choice_answer,
    record_skip,
    record_text_answer,
    start_session,
    toggle_multi_option,
)
from quiz_loader import load_quiz
from result_manager import save_answer_sheet_json, save_answer_sheet_txt, save_result_summary


BASE_DIR = Path(__file__).resolve().parent
TEST_FILE = BASE_DIR / "tests" / "a2_grammar_01.json"


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    keyboard = InlineKeyboardMarkup(
        [[InlineKeyboardButton("Start Quiz", callback_data="start_quiz")]]
    )

    await update.message.reply_text(
        "Welcome to Smith English Quiz Bot.\n\nPress Start Quiz when you are ready.",
        reply_markup=keyboard,
    )


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    help_text = (
        "Smith gives English tests in Telegram.\n\n"
        "- Some questions are single choice.\n"
        "- Some are multiple choice.\n"
        "- Some require typed answers.\n"
        "- Choice questions may be skipped only within the allowed skip limit.\n"
        "- Text questions cannot be skipped."
    )
    await update.message.reply_text(help_text)


async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    if not query or not query.data:
        return

    data = query.data
    user_id = query.from_user.id

    if data == "start_quiz":
        await query.answer()
        existing_session = get_session(user_id)
        if existing_session:
            await cleanup_current_question_messages(
                context,
                existing_session["chat_id"],
                existing_session["current_question_message_ids"],
            )
            end_session(user_id)

        try:
            quiz = load_quiz(str(TEST_FILE))
        except Exception as error:
            await query.message.reply_text(f"Could not load quiz: {error}")
            return

        start_session(query.from_user, query.message.chat_id, quiz)
        await query.message.edit_text("Starting your test. Good luck!")
        await send_current_question(context, user_id)
        return

    session = get_session(user_id)
    if not session:
        await query.answer()
        return

    parts = data.split("|")
    action = parts[0]

    if action == "answer" and len(parts) == 3:
        question_index = _safe_int(parts[1])
        option_index = _safe_int(parts[2])
        if question_index is None or option_index is None:
            await query.answer()
            return

        if not _is_current_question(session, question_index):
            await query.answer()
            return
        if already_answered(user_id, question_index):
            await query.answer()
            return

        answer = record_single_choice_answer(user_id, question_index, option_index)
        if not answer:
            await query.answer()
            return

        await query.answer()
        await cleanup_current_question_messages(
            context, session["chat_id"], session["current_question_message_ids"]
        )
        move_to_next_question(user_id)

        if is_finished(user_id):
            await finish_quiz(context, user_id)
        else:
            await send_current_question(context, user_id)
        return

    if action == "toggle_multi" and len(parts) == 3:
        question_index = _safe_int(parts[1])
        option_index = _safe_int(parts[2])
        if question_index is None or option_index is None:
            await query.answer()
            return

        if not _is_current_question(session, question_index):
            await query.answer()
            return
        if already_answered(user_id, question_index):
            await query.answer()
            return

        selected = toggle_multi_option(user_id, question_index, option_index)
        if selected is None:
            await query.answer()
            return

        question = get_current_question(user_id)
        keyboard = build_multiple_choice_keyboard(user_id, question_index, question)
        await query.answer()
        try:
            await query.edit_message_reply_markup(reply_markup=keyboard)
        except TelegramError:
            pass
        return

    if action == "submit_multi" and len(parts) == 2:
        question_index = _safe_int(parts[1])
        if question_index is None:
            await query.answer()
            return

        if not _is_current_question(session, question_index):
            await query.answer()
            return
        if already_answered(user_id, question_index):
            await query.answer()
            return

        if not get_multi_selected(user_id, question_index):
            await query.answer(
                "Choose at least one answer before submitting.",
                show_alert=True,
            )
            return

        answer = record_multiple_choice_answer(user_id, question_index)
        if not answer:
            await query.answer()
            return

        await query.answer()
        await cleanup_current_question_messages(
            context, session["chat_id"], session["current_question_message_ids"]
        )
        move_to_next_question(user_id)

        if is_finished(user_id):
            await finish_quiz(context, user_id)
        else:
            await send_current_question(context, user_id)
        return

    if action == "skip" and len(parts) == 2:
        question_index = _safe_int(parts[1])
        if question_index is None:
            await query.answer()
            return

        question = get_current_question(user_id)
        if question and question["type"] == "text_input":
            await query.answer(
                "Text questions cannot be skipped. Please type your answer.",
                show_alert=True,
            )
            return

        if not _is_current_question(session, question_index):
            await query.answer()
            return
        if already_answered(user_id, question_index):
            await query.answer()
            return

        if not can_skip(user_id):
            await query.answer(
                "You have already used your available skip for this test.",
                show_alert=True,
            )
            return

        skipped = record_skip(user_id, question_index)
        if not skipped:
            await query.answer()
            return

        await query.answer()
        await cleanup_current_question_messages(
            context, session["chat_id"], session["current_question_message_ids"]
        )
        move_to_next_question(user_id)

        if is_finished(user_id):
            await finish_quiz(context, user_id)
        else:
            await send_current_question(context, user_id)
        return

    await query.answer()


async def receive_text_answer(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not update.message or not update.effective_user:
        return

    user_id = update.effective_user.id
    session = get_session(user_id)
    if not session:
        return

    question = get_current_question(user_id)
    if not question:
        return

    if question["type"] != "text_input":
        await update.message.reply_text("Use the buttons to answer the current question.")
        return

    question_index = session["current_question_index"]
    if already_answered(user_id, question_index):
        return

    answer = record_text_answer(user_id, question_index, update.message.text)
    if not answer:
        return

    await cleanup_current_question_messages(
        context, session["chat_id"], session["current_question_message_ids"]
    )

    try:
        await update.message.delete()
    except TelegramError:
        pass

    move_to_next_question(user_id)
    if is_finished(user_id):
        await finish_quiz(context, user_id)
    else:
        await send_current_question(context, user_id)


async def send_current_question(context: ContextTypes.DEFAULT_TYPE, user_id: int) -> None:
    session = get_session(user_id)
    question = get_current_question(user_id)
    if not session or not question:
        return

    question_index = session["current_question_index"]
    total_questions = get_total_questions(user_id)
    text_lines = [f"Question {question_index + 1}/{total_questions}", question["question"], ""]

    if question["type"] in {"single_choice", "multiple_choice"}:
        for index, option in enumerate(question["options"]):
            text_lines.append(f"{_option_label(index)}) {option}")
    else:
        text_lines.append("Type your answer below.")

    reply_markup = None
    if question["type"] == "single_choice":
        reply_markup = build_single_choice_keyboard(user_id, question_index, question)
    elif question["type"] == "multiple_choice":
        reply_markup = build_multiple_choice_keyboard(user_id, question_index, question)

    message = await context.bot.send_message(
        chat_id=session["chat_id"],
        text="\n".join(text_lines),
        reply_markup=reply_markup,
    )

    session["current_question_message_ids"] = [message.message_id]


async def cleanup_current_question_messages(
    context: ContextTypes.DEFAULT_TYPE, chat_id: int, message_ids: list[int]
) -> None:
    for message_id in list(message_ids):
        try:
            await context.bot.delete_message(chat_id=chat_id, message_id=message_id)
        except TelegramError:
            pass

    message_ids.clear()


async def finish_quiz(context: ContextTypes.DEFAULT_TYPE, user_id: int) -> None:
    session = get_session(user_id)
    if not session:
        return

    result = build_result(user_id)
    if not result:
        return

    answer_sheet_json_path = save_answer_sheet_json(result)
    answer_sheet_txt_path = save_answer_sheet_txt(result)

    summary = {
        "user_id": result["user_id"],
        "name": result["name"],
        "username": result["username"],
        "test_name": result["test_name"],
        "level": result["level"],
        "version": result["version"],
        "started_at": result["started_at"],
        "finished_at": result["finished_at"],
        "elapsed_seconds": result["elapsed_seconds"],
        "total_questions": result["total_questions"],
        "answered_questions": result["answered_questions"],
        "skipped_questions": result["skipped_questions"],
        "correct": result["correct"],
        "wrong": result["wrong"],
        "percentage": result["percentage"],
        "answer_sheet_json_path": answer_sheet_json_path,
        "answer_sheet_txt_path": answer_sheet_txt_path,
    }
    save_result_summary(summary)

    final_message = build_final_result_message(result)
    for chunk in split_message(final_message):
        await context.bot.send_message(chat_id=session["chat_id"], text=chunk)

    await context.bot.send_message(
        chat_id=session["chat_id"],
        text=(
            "Your answer sheet has been created.\n\n"
            f"Answered: {result['answered_questions']}\n"
            f"Skipped: {result['skipped_questions']}\n"
            f"Correct: {result['correct']}\n"
            f"Wrong: {result['wrong']}"
        ),
    )

    try:
        with open(answer_sheet_txt_path, "rb") as answer_sheet_file:
            await context.bot.send_document(
                chat_id=session["chat_id"],
                document=answer_sheet_file,
                filename=Path(answer_sheet_txt_path).name,
            )
    except Exception:
        pass

    end_session(user_id)


def build_single_choice_keyboard(
    user_id: int, question_index: int, question: dict
) -> InlineKeyboardMarkup:
    buttons = [
        InlineKeyboardButton(
            _option_label(index),
            callback_data=f"answer|{question_index}|{index}",
        )
        for index in range(len(question["options"]))
    ]

    keyboard = _chunk_buttons(buttons, 2)
    if can_skip(user_id):
        keyboard.append(
            [InlineKeyboardButton("Skip Question", callback_data=f"skip|{question_index}")]
        )

    return InlineKeyboardMarkup(keyboard)


def build_multiple_choice_keyboard(
    user_id: int, question_index: int, question: dict
) -> InlineKeyboardMarkup:
    selected = set(get_multi_selected(user_id, question_index))
    buttons = []
    for index in range(len(question["options"])):
        prefix = "✅" if index in selected else "☐"
        buttons.append(
            InlineKeyboardButton(
                f"{prefix} {_option_label(index)}",
                callback_data=f"toggle_multi|{question_index}|{index}",
            )
        )

    keyboard = _chunk_buttons(buttons, 2)
    keyboard.append(
        [InlineKeyboardButton("Submit Answer", callback_data=f"submit_multi|{question_index}")]
    )
    if can_skip(user_id):
        keyboard.append(
            [InlineKeyboardButton("Skip Question", callback_data=f"skip|{question_index}")]
        )

    return InlineKeyboardMarkup(keyboard)


def build_final_result_message(result: dict) -> str:
    lines = [
        "Quiz finished!",
        "",
        f"Name: {result['name']}",
        f"Test: {result['test_name']}",
        f"Level: {result['level']}",
        f"Version: {result['version']}",
        f"Time: {result['elapsed_text']}",
        "",
        f"Score: {result['correct']}/{result['total_questions']}",
        f"Wrong: {result['wrong']}",
        f"Skipped: {result['skipped_questions']}",
        f"Percentage: {result['percentage']}%",
        "",
    ]

    mistakes = [answer for answer in result["full_answer_review"] if not answer["is_correct"]]
    if not mistakes:
        lines.append("Excellent! No mistakes.")
        return "\n".join(lines)

    lines.extend(["Mistakes:", ""])
    for index, answer in enumerate(mistakes, start=1):
        lines.extend(
            [
                f"{index}. {answer['question_text']}",
                f"Your answer: {_format_result_user_answer(answer)}",
                f"{_correct_answer_label(answer)}: {_format_result_correct_answer(answer)}",
                f"Explanation: {answer['explanation']}",
                "",
            ]
        )

    return "\n".join(lines).strip()


def split_message(text: str, limit: int = 4000) -> list[str]:
    if len(text) <= limit:
        return [text]

    chunks = []
    current_chunk = ""
    for line in text.splitlines(keepends=True):
        if len(current_chunk) + len(line) > limit:
            chunks.append(current_chunk.rstrip())
            current_chunk = line
        else:
            current_chunk += line

    if current_chunk:
        chunks.append(current_chunk.rstrip())

    return chunks


def _chunk_buttons(
    buttons: list[InlineKeyboardButton], row_size: int
) -> list[list[InlineKeyboardButton]]:
    return [buttons[index:index + row_size] for index in range(0, len(buttons), row_size)]


def _is_current_question(session: dict, question_index: int) -> bool:
    return question_index == session["current_question_index"]


def _option_label(index: int) -> str:
    return chr(ord("A") + index)


def _safe_int(value: str) -> int | None:
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _format_result_user_answer(answer: dict) -> str:
    if answer["was_skipped"]:
        return "Skipped"
    if answer["type"] == "single_choice":
        return answer["user_answer_text"]
    if answer["type"] == "multiple_choice":
        return ", ".join(answer["user_answer_texts"])
    return answer["user_answer_text"] or "(empty)"


def _format_result_correct_answer(answer: dict) -> str:
    if answer["type"] == "single_choice":
        return answer["correct_answer_text"]
    if answer["type"] == "multiple_choice":
        return ", ".join(answer["correct_answer_texts"])
    return ", ".join(answer["correct_answer_texts"])


def _correct_answer_label(answer: dict) -> str:
    if answer["type"] == "text_input":
        return "Accepted answers"
    return "Correct answer"


def main() -> None:
    application = ApplicationBuilder().token(BOT_TOKEN).build()
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CallbackQueryHandler(button_handler))
    application.add_handler(
        MessageHandler(filters.TEXT & ~filters.COMMAND, receive_text_answer)
    )

    application.run_polling()


if __name__ == "__main__":
    main()
